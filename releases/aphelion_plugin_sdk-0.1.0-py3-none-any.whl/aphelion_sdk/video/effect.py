"""Base class for user-defined Aphelion node plugins."""

from __future__ import annotations

from abc import abstractmethod
from typing import ClassVar

from aphelion_sdk.plugin import Plugin
from aphelion_sdk.widgets.host import WidgetView

from core.nodes.base import NodeSocketType, NodeValue
from core.nodes.frame_base import FrameNode


class VideoEffectPlugin(Plugin, FrameNode):
    """Base class for user-defined video/audio/general-purpose nodes.

    Plugins are not required to return video frames.

    A plugin may define arbitrary input/output sockets using
    ``add_input()`` and ``add_output()`` and may return any valid
    ``NodeValue`` supported by the node system.

    Example:

        class MyPlugin(VideoEffectPlugin):

            plugin_name = "My Plugin"

            def setup_input_outputs(self):
                self.add_input("video", NodeSocketType.Frame)
                self.add_input("audio", NodeSocketType.Audio)
                self.add_input("amount", NodeSocketType.Number)

                self.add_output("video", NodeSocketType.Frame)
                self.add_output("audio", NodeSocketType.Audio)

            def setup_effect_properties(self):
                ...

            def evaluate(self, frame_num):
                video = self.input_frame("video")
                audio = self.input_audio("audio")
                amount = self.float_value("amount", 1.0)

                ...

                return {
                    "video": video,
                    "audio": audio,
                }
    """

    plugin_kind: ClassVar[str] = "video"
    plugin_name: ClassVar[str] = "Untitled Node"

    # ------------------------------------------------------------------
    # Socket definition
    # ------------------------------------------------------------------

    def _setup_sockets(self) -> None:
        """Called automatically by Node.__init__().

        The plugin completely controls its socket layout.
        """
        self.setup_input_outputs()

    @abstractmethod
    def setup_input_outputs(self) -> None:
        """Declare the node's input and output sockets.

        Plugins can create any combination of supported socket types.

        Example::

            self.add_input("image", NodeSocketType.Frame)
            self.add_input("mask", NodeSocketType.Mask)
            self.add_input("amount", NodeSocketType.Number)
            self.add_input("audio", NodeSocketType.Audio)

            self.add_output("image", NodeSocketType.Frame)
            self.add_output("audio", NodeSocketType.Audio)
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @abstractmethod
    def setup_effect_properties(self) -> None:
        """Declare the node's editable properties."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    @abstractmethod
    def evaluate(self, frame_num: int) -> NodeValue:
        """Evaluate the node for a frame.

        The return value is intentionally ``NodeValue`` rather than
        ``Frame``.

        A node can return:

        * ``np.ndarray`` for a frame
        * ``float`` for a numeric output
        * ``AudioData`` for audio
        * ``FrameWithAudio`` for combined media
        * ``dict[str, ...]`` for multiple outputs

        The dictionary keys should correspond to the node's output
        socket names.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Custom UI
    # ------------------------------------------------------------------

    def build_property_panel(self) -> WidgetView | None:
        """Build a custom plugin property panel."""
        return None

    def build_property_qt_widget(self) -> object | None:
        """Build a native Qt property widget."""
        return None
